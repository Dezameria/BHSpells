package net.offkung.bhweapons.animation.custom;

import com.mojang.datafixers.util.Pair;
import com.p1nero.wukong.client.event.CameraAnim;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;
import yesman.epicfight.api.animation.AnimationManager.AnimationAccessor;
import yesman.epicfight.api.animation.property.AnimationEvent.Side;
import yesman.epicfight.api.animation.property.AnimationEvent.SimpleEvent;
import yesman.epicfight.api.animation.property.AnimationProperty.ActionAnimationProperty;
import yesman.epicfight.api.animation.property.AnimationProperty.StaticAnimationProperty;
import yesman.epicfight.api.animation.types.AttackAnimation;
import yesman.epicfight.api.animation.types.AttackAnimation.Phase;
import yesman.epicfight.api.animation.types.DynamicAnimation;
import yesman.epicfight.api.animation.types.EntityState;
import yesman.epicfight.api.asset.AssetAccessor;
import yesman.epicfight.api.utils.math.Vec3f;
import yesman.epicfight.gameasset.Armatures;
import yesman.epicfight.model.armature.HumanoidArmature;
import yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch;

public class StaffCharybdisLoopFastAnimation extends AttackAnimation {
    private static final float FAST_PLAY_SPEED = 0.7F;
    private static final float LOOP_START = 0.60F;
    private static final float LOOP_END = 0.80F;
    private static final float LOOP_PERIOD = LOOP_END - LOOP_START;

    public StaffCharybdisLoopFastAnimation(AnimationAccessor<? extends AttackAnimation> accessor) {
        super(0.0F, accessor, Armatures.BIPED, buildPhases());

        this.setResourceLocation("wom", "biped/skill/staff_charybdisandscylla");

        this.addProperty(ActionAnimationProperty.CANCELABLE_MOVE, false);
        this.addProperty(ActionAnimationProperty.STOP_MOVEMENT, true);
        this.addProperty(ActionAnimationProperty.REMOVE_DELTA_MOVEMENT, true);
        this.addProperty(StaticAnimationProperty.PLAY_SPEED_MODIFIER, (dynamicAnimation, entitypatch, speed, prevElapsedTime, elapsedTime) -> FAST_PLAY_SPEED);

        // Seamless internal looping: when the spin cycle reaches LOOP_END (0.80s), it wraps back to LOOP_START (0.60s).
        // The bone poses at 0.80s and 0.60s are an exact 360-degree match, ensuring continuous rotation without stutter.
        this.addProperty(StaticAnimationProperty.ELAPSED_TIME_MODIFIER, (dynamicAnimation, entitypatch, speed, prevElapsedTime, elapsedTime) -> {
            if (elapsedTime >= LOOP_END) {
                float excess = (elapsedTime - LOOP_START) % LOOP_PERIOD;
                float newElapsed = LOOP_START + excess;
                float delta = elapsedTime - prevElapsedTime;
                float newPrev = newElapsed - delta;
                return Pair.of(newPrev, newElapsed);
            }
            return Pair.of(prevElapsedTime, elapsedTime);
        });

        this.addEvents(StaticAnimationProperty.ON_BEGIN_EVENTS, SimpleEvent.create((entitypatch, animation, params) -> {
            if (entitypatch.getOriginal() instanceof LocalPlayer) {
                if (!CameraAnim.isAiming()) {
                    CameraAnim.zoomIn(new Vec3f(-1.0F, 0.0F, 1.25F), 20);
                }
            }
        }, Side.CLIENT));

        // Disable root motion and forced movement so the player remains stationary in place while spinning
        this.addProperty(ActionAnimationProperty.COORD_SET_BEGIN, null);
        this.addProperty(ActionAnimationProperty.COORD_SET_TICK, null);
        this.addProperty(ActionAnimationProperty.MOVE_VERTICAL, false);
        // Allow the player to rotate and face their crosshair direction
        this.addProperty(ActionAnimationProperty.ENTITY_YROT_PROVIDER, (self, entitypatch) -> entitypatch.getOriginal().yHeadRot);
    }

    private static Phase[] buildPhases() {
        HumanoidArmature biped = Armatures.BIPED.get();

        return new Phase[]{
                new Phase(0.0F, 0.1F, 0.14F, 0.15F, 0.15F, biped.toolR, null),
                new Phase(0.15F, 0.2F, 0.24F, 0.25F, 0.25F, biped.toolR, null),
                new Phase(0.25F, 0.3F, 0.34F, 0.35F, 0.35F, biped.toolR, null),
                new Phase(0.35F, 0.4F, 0.44F, 0.45F, 0.45F, biped.toolR, null),
                new Phase(0.45F, 0.55F, 0.59F, 0.6F, 0.6F, biped.toolR, null),
                new Phase(0.6F, 0.65F, 0.69F, 0.7F, 0.7F, biped.toolR, null),
                new Phase(0.7F, 0.75F, 0.79F, 0.8F, 0.8F, biped.toolR, null),
                new Phase(0.8F, 0.85F, 0.89F, LOOP_END, LOOP_END, biped.toolR, null)
        };
    }

    @Override
    public boolean isRepeat() {
        return true;
    }

    @Override
    protected Vec3 getCoordVector(LivingEntityPatch<?> entitypatch, AssetAccessor<? extends DynamicAnimation> dynamicAnimation) {
        return Vec3.ZERO;
    }

    @Override
    protected void hurtCollidingEntities(LivingEntityPatch<?> entitypatch, float prevElapsedTime, float elapsedTime, EntityState prevState, EntityState state, Phase phase) {
    }

    @Override
    public void end(LivingEntityPatch<?> entitypatch, AssetAccessor<? extends DynamicAnimation> nextAnimation, boolean isEnd) {
        super.end(entitypatch, nextAnimation, isEnd);
        if (entitypatch.isLogicalClient() && CameraAnim.isAiming()) {
            if (nextAnimation == null || nextAnimation.get() != this) {
                CameraAnim.zoomOut(20);
            }
        }
        if (isEnd && !entitypatch.isLogicalClient()) {
            entitypatch.playAnimationSynchronized(this.getAccessor(), -LOOP_START);
        }
    }
}
