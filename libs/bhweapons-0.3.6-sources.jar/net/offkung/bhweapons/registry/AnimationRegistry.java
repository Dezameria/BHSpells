package net.offkung.bhweapons.registry;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import yesman.epicfight.api.animation.AnimationManager;
import yesman.epicfight.api.animation.property.MoveCoordFunctions;
import yesman.epicfight.api.animation.types.ActionAnimation;
import yesman.epicfight.api.animation.types.AttackAnimation;
import yesman.epicfight.api.animation.types.EntityState;
import yesman.epicfight.api.animation.property.AnimationProperty;
import yesman.epicfight.gameasset.Armatures;
import yesman.epicfight.gameasset.ColliderPreset;
import yesman.epicfight.gameasset.Animations.ReusableSources;
import net.offkung.bhweapons.BHWeapons;
import net.offkung.bhweapons.animation.custom.StaffCharybdisLoopFastAnimation;
import net.offkung.bhweapons.animation.custom.StaffSpinTwoHandLoopFastAnimation;

@Mod.EventBusSubscriber(modid = BHWeapons.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class AnimationRegistry {
    public static AnimationManager.AnimationAccessor<AttackAnimation> FAST_STEEL_WHIRLWIND;
    public static AnimationManager.AnimationAccessor<ActionAnimation> MY_CUSTOM_ANIM;
    public static AnimationManager.AnimationAccessor<ActionAnimation> TORMENT_CHARGED_ATTACK_3;
    public static AnimationManager.AnimationAccessor<AttackAnimation> STAFF_SPIN_TWOHAND_LOOP_FAST;
    public static AnimationManager.AnimationAccessor<AttackAnimation> STAFF_CHARYBDIS_LOOP_FAST;

    @SubscribeEvent
    public static void registerAnimations(AnimationManager.AnimationRegistryEvent event) {
        event.newBuilder(BHWeapons.MODID, AnimationRegistry::build);
    }

    public static void build(AnimationManager.AnimationBuilder builder) {
        FAST_STEEL_WHIRLWIND = builder.nextAccessor("biped/skill/fast_steel_whirlwind", accessor -> new
        AttackAnimation(0.15f, accessor, Armatures.BIPED, new
        AttackAnimation.Phase(0.0f, 0.0f, 0.0f, 0.2f, 0.45f, 0.45f, Armatures.BIPED.get().rootJoint,
        ColliderPreset.STEEL_WHIRLWIND), new AttackAnimation.Phase(0.45f, 0.45f, 0.45f, 0.65f, 1.0f, 1.0f,
        Armatures.BIPED.get().rootJoint, ColliderPreset.STEEL_WHIRLWIND), new AttackAnimation.Phase(1.0f,
        1.0f, 1.0f, 1.2f, 2.55f, Float.MAX_VALUE, Armatures.BIPED.get().rootJoint, ColliderPreset.STEEL_WHIRLWIND)).addProperty(AnimationProperty.AttackAnimationProperty.BASIS_ATTACK_SPEED, 1.0f).addProperty(AnimationProperty.AttackAnimationProperty.EXTRA_COLLIDERS, 4).addProperty(AnimationProperty.ActionAnimationProperty.COORD_SET_BEGIN, (animation, entitypatch, transformSheet) -> {
            if (!animation.isLinkAnimation()) {
                transformSheet.readFrom(animation.getCoord().copyAll().extendsZCoord(0.6666f + 2.0f / 5.0f, 0, 2));
            } else {
                MoveCoordFunctions.RAW_COORD.set(animation, entitypatch, transformSheet);
            }
        }).addProperty(AnimationProperty.ActionAnimationProperty.COORD_SET_TICK, null).addProperty(AnimationProperty.ActionAnimationProperty.MOVE_VERTICAL, false).addProperty(AnimationProperty.ActionAnimationProperty.ENTITY_YROT_PROVIDER, (self, entitypatch) -> {
            return entitypatch.getOriginal().yHeadRot;
        }).addProperty(AnimationProperty.StaticAnimationProperty.POSE_MODIFIER, ReusableSources.COMBO_ATTACK_DIRECTION_MODIFIER).addProperty(AnimationProperty.StaticAnimationProperty.PLAY_SPEED_MODIFIER, (self, entitypatch, speed, prevElapsedTime, elapsedTime) -> {
            if (elapsedTime < 1.05f) {
                return 1.2f;
            }
            return 1.5f;
        }).newTimePair(0.0f, 2.55f).addStateRemoveOld(EntityState.CAN_SKILL_EXECUTION, false));

        MY_CUSTOM_ANIM = builder.nextAccessor("chen_yinyue_flag", (accessor) -> new ActionAnimation(0.15F, accessor, Armatures.BIPED));
        TORMENT_CHARGED_ATTACK_3 = builder.nextAccessor("torment_charged_attack_3", (accessor) -> new ActionAnimation(0.15F, accessor, Armatures.BIPED));
        STAFF_SPIN_TWOHAND_LOOP_FAST = builder.nextAccessor("staff_spin_twohand_loop_fast", StaffSpinTwoHandLoopFastAnimation::new);
        STAFF_CHARYBDIS_LOOP_FAST = builder.nextAccessor("staff_charybdis_loop_fast", StaffCharybdisLoopFastAnimation::new);
    }
}
