package net.offkung.bhweapons.registry;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.offkung.bhweapons.BHWeapons;
import net.offkung.bhweapons.item.beeboych_marble.BeeBoyCHMarbleItem;
import net.offkung.bhweapons.item.flint_knuckle_gloves.FlintKnuckleGloves;
import net.offkung.bhweapons.item.lu_xingxuan_xinghao.XingHaoItem;
import net.offkung.bhweapons.item.mobai_hanzhi.MobaiHanzhiItem;
import net.offkung.bhweapons.item.mun_tiw.MunTiwItem;
import net.offkung.bhweapons.item.nippon_sword.NipponSwordItem;
import net.offkung.bhweapons.item.taixu_zhenxie.TaixuZhenxieItem;
import net.offkung.bhweapons.item.taixu_zhenxie.TaixuZhenxieSheathItem;
import net.offkung.bhweapons.item.wuchen_jian.WuchenJianItem;
import net.offkung.bhweapons.item.wuchen_jian.WuchenJianSheathItem;
import net.offkung.bhweapons.item.yang_fan.CloseYangFanItem;
import net.offkung.bhweapons.item.yang_fan.OpenYangFanItem;
import net.offkung.bhweapons.item.yaoyao_pokpak.YaoYaoSwordItem;
import net.offkung.bhweapons.item.yinyue_axe.YinyueAxeItem;
import net.offkung.bhweapons.item.zhilan_zhes_han.ZhilanZhesHan;

public class ItemRegistry {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, BHWeapons.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BHWeapons.MODID);

    // Weapons Item
    public static final RegistryObject<Item> NIPPON_SWORD = ITEMS.register("nippon_sword", () -> new NipponSwordItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> YINYUE_AXE = ITEMS.register("yinyue_axe", () -> new YinyueAxeItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> YAOYAO_POKPAK = ITEMS.register("yaoyao_pokpak", () -> new YaoYaoSwordItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> BEEBOYCH_MARBLE = ITEMS.register("beeboych_marble", () -> new BeeBoyCHMarbleItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> MOBAI_HANZHI = ITEMS.register("mobai_hanzhi", () -> new MobaiHanzhiItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> MUN_TIW = ITEMS.register("mun_tiw", () -> new MunTiwItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> WUCHEN_JIAN_SHEATH = ITEMS.register("wuchen_jian_sheath", () -> new WuchenJianSheathItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> WUCHEN_JIAN_SWORD = ITEMS.register("wuchen_jian_sword", () -> new WuchenJianItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> XINGHAO = ITEMS.register("lu_xingxuan_xinghao", () -> new XingHaoItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> TAIXU_ZHENXIE_SHEATH = ITEMS.register("taixu_zhenxie_sheath", () -> new TaixuZhenxieSheathItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> TAIXU_ZHENXIE = ITEMS.register("taixu_zhenxie", () -> new TaixuZhenxieItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> ZHILAN_ZHES_HAN = ITEMS.register("zhilan_zhes_han", () -> new ZhilanZhesHan(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> FLINT_KNUCKLE_GLOVES = ITEMS.register("flint_knuckle_gloves", () -> new FlintKnuckleGloves(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> CLOSE_YANG_FAN = ITEMS.register("close_yang_fan", () -> new CloseYangFanItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));
    public static final RegistryObject<Item> OPEN_YANG_FAN = ITEMS.register("open_yang_fan", () -> new OpenYangFanItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(1)));

    // Soul Item
    public static final RegistryObject<Item> BLUE_SOUL = ITEMS.register("blue_soul_icon", () -> new Item(new Item.Properties().rarity(Rarity.EPIC).stacksTo(1)));
    public static final RegistryObject<Item> GREEN_SOUL = ITEMS.register("green_soul_icon", () -> new Item(new Item.Properties().rarity(Rarity.EPIC).stacksTo(1)));
    public static final RegistryObject<Item> LIGHT_BLUE_SOUL = ITEMS.register("light_blue_soul_icon", () -> new Item(new Item.Properties().rarity(Rarity.EPIC).stacksTo(1)));
    public static final RegistryObject<Item> ORANGE_SOUL = ITEMS.register("orange_soul_icon", () -> new Item(new Item.Properties().rarity(Rarity.EPIC).stacksTo(1)));
    public static final RegistryObject<Item> PURPLE_SOUL = ITEMS.register("purple_soul_icon", () -> new Item(new Item.Properties().rarity(Rarity.EPIC).stacksTo(1)));
    public static final RegistryObject<Item> RED_SOUL = ITEMS.register("red_soul_icon", () -> new Item(new Item.Properties().rarity(Rarity.EPIC).stacksTo(1)));
    public static final RegistryObject<Item> YELLOW_SOUL = ITEMS.register("yellow_soul_icon", () -> new Item(new Item.Properties().rarity(Rarity.EPIC).stacksTo(1)));

    public static final RegistryObject<CreativeModeTab> BHWEAPONS_TAB = TABS.register("bhweapons", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup." + BHWeapons.MODID + ".bhweapons_tab"))
            .icon(() -> new ItemStack(NIPPON_SWORD.get()))
            .displayItems((enabledFeatures, entries) -> {
                entries.accept(NIPPON_SWORD.get());
                entries.accept(YINYUE_AXE.get());
                entries.accept(YAOYAO_POKPAK.get());
                entries.accept(BEEBOYCH_MARBLE.get());
                entries.accept(MOBAI_HANZHI.get());
                entries.accept(MUN_TIW.get());
                entries.accept(WUCHEN_JIAN_SWORD.get());
                entries.accept(XINGHAO.get());
                entries.accept(TAIXU_ZHENXIE.get());
                entries.accept(ZHILAN_ZHES_HAN.get());
                entries.accept(FLINT_KNUCKLE_GLOVES.get());
                entries.accept(CLOSE_YANG_FAN.get());
            })
            .build());
}
