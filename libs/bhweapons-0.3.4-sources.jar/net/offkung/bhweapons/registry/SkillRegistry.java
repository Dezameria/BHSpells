package net.offkung.bhweapons.registry;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.offkung.bhweapons.BHWeapons;
import net.offkung.bhweapons.skill.FastSteelWhirlwindSkill;
import yesman.epicfight.api.forgeevent.SkillBuildEvent;
import yesman.epicfight.skill.Skill;
import yesman.epicfight.skill.SkillBuilder;
import yesman.epicfight.skill.weaponinnate.SimpleWeaponInnateSkill;

@Mod.EventBusSubscriber(modid = BHWeapons.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class SkillRegistry {
    public static Skill FAST_STEEL_WHIRLWIND;

    @SubscribeEvent
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void buildSkillEvent(SkillBuildEvent build) {
        SkillBuildEvent.ModRegistryWorker modRegistry = build.createRegistryWorker(BHWeapons.MODID);
        FAST_STEEL_WHIRLWIND = modRegistry.build("fast_steel_whirlwind", FastSteelWhirlwindSkill::new,
            (SkillBuilder)SimpleWeaponInnateSkill.createSimpleWeaponInnateBuilder()
        );
    }
}
