package net.offkung.bhweapons.skill;

import net.minecraft.network.FriendlyByteBuf;
import net.offkung.bhweapons.registry.AnimationRegistry;
import yesman.epicfight.api.animation.types.AttackAnimation;
import yesman.epicfight.skill.SkillBuilder;
import yesman.epicfight.skill.SkillContainer;
import yesman.epicfight.skill.weaponinnate.WeaponInnateSkill;
import java.util.Map;

public class FastSteelWhirlwindSkill extends WeaponInnateSkill {
    public FastSteelWhirlwindSkill(SkillBuilder<? extends WeaponInnateSkill> builder) {
        super(builder);
    }

    @Override
    public void executeOnServer(SkillContainer container, FriendlyByteBuf args) {
        container.getExecutor().playAnimationSynchronized(AnimationRegistry.FAST_STEEL_WHIRLWIND, 0.0f);
        super.executeOnServer(container, args);
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public WeaponInnateSkill registerPropertiesToAnimation() {
        AttackAnimation anim = AnimationRegistry.FAST_STEEL_WHIRLWIND.get();
        if (this.properties.size() > 0 && anim.phases != null) {
            for (AttackAnimation.Phase phase : anim.phases) {
                phase.addProperties(((Map)this.properties.get(0)).entrySet());
            }
        }
        return this;
    }
}
