package net.offkung.bhweapons.event;

import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingEvent.LivingTickEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.offkung.bhweapons.BHWeapons;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Mod.EventBusSubscriber(modid = BHWeapons.MODID)
public class NightfallFireCompat {
    private static final Map<UUID, Integer> PRE_TICK_FIRE_TICKS = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> PRE_DAMAGE_FIRE_TICKS = new ConcurrentHashMap<>();
    private static final int MAX_RESTORED_FIRE_TICKS = 140;

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void captureBeforeTick(LivingTickEvent event) {
        if (event.getEntity() instanceof Player player) {
            PRE_TICK_FIRE_TICKS.put(player.getUUID(), player.getRemainingFireTicks());
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void restoreAfterTick(LivingTickEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }

        Integer before = PRE_TICK_FIRE_TICKS.remove(player.getUUID());
        if (before != null && before > 20 && player.getRemainingFireTicks() < before) {
            player.setRemainingFireTicks(Math.min(before, MAX_RESTORED_FIRE_TICKS));
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void captureBeforeAttack(LivingAttackEvent event) {
        if (event.getEntity() instanceof Player player && event.getSource().is(DamageTypeTags.IS_FIRE)) {
            PRE_DAMAGE_FIRE_TICKS.put(player.getUUID(), player.getRemainingFireTicks());
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingAttack(LivingAttackEvent event) {
        if (event.isCanceled() && event.getEntity() instanceof Player && event.getSource().is(DamageTypeTags.IS_FIRE)) {
            event.setCanceled(false);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingDamage(LivingDamageEvent event) {
        if (!(event.getEntity() instanceof Player player) || !event.getSource().is(DamageTypeTags.IS_FIRE)) {
            return;
        }

        Integer before = PRE_DAMAGE_FIRE_TICKS.remove(player.getUUID());
        if (before != null && before > 0 && player.getRemainingFireTicks() < before) {
            player.setRemainingFireTicks(Math.min(before, MAX_RESTORED_FIRE_TICKS));
        }
    }
}
