package net.offkung.bhweapons;

import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.offkung.bhweapons.item.flint_knuckle_gloves.FlintKnuckleGloves;
import net.offkung.bhweapons.network.PacketHandler;
import net.offkung.bhweapons.registry.ItemRegistry;
import org.slf4j.Logger;
import yesman.epicfight.api.forgeevent.WeaponCapabilityPresetRegistryEvent;
import yesman.epicfight.world.capabilities.item.CapabilityItem;
import yesman.epicfight.world.capabilities.item.WeaponCapabilityPresets;
import yesman.epicfight.world.capabilities.provider.ItemCapabilityProvider;

@Mod(BHWeapons.MODID)
public class BHWeapons {
    public static final String MODID = "bhweapons";
    public static final Logger LOGGER = LogUtils.getLogger();

    public BHWeapons(FMLJavaModLoadingContext context) {
        IEventBus modEventBus = context.getModEventBus();
        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::registerWeaponCapabilityPresets);
        ItemRegistry.ITEMS.register(modEventBus);
        ItemRegistry.TABS.register(modEventBus);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            PacketHandler.registerPackets();
            CapabilityItem mobaiBowCapability = WeaponCapabilityPresets.BOW.apply(ItemRegistry.MOBAI_HANZHI.get()).build();
            ItemCapabilityProvider.put(ItemRegistry.MOBAI_HANZHI.get(), mobaiBowCapability);
        });
        LOGGER.info("BHWeapons Common Setup Initialized!");
    }

    private void registerWeaponCapabilityPresets(WeaponCapabilityPresetRegistryEvent event) {
        event.getTypeEntry().put(
            ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "mobai_bow"),
            WeaponCapabilityPresets.BOW
        );
    }

    @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event) {
        if (event.getSource().getEntity() instanceof LivingEntity attacker) {
            ItemStack mainHand = attacker.getMainHandItem();
            ItemStack offHand = attacker.getOffhandItem();
            if (mainHand.getItem() instanceof FlintKnuckleGloves || offHand.getItem() instanceof FlintKnuckleGloves) {
                event.getEntity().setSecondsOnFire(10);
            }
        }
    }

    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        LOGGER.info("BHWeapons Server Script Starting!");
    }
}