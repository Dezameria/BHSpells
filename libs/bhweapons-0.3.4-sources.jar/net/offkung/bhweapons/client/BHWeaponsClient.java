package net.offkung.bhweapons.client;

import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.offkung.bhweapons.BHWeapons;
import net.offkung.bhweapons.client.layer.MobaiHanzhiSlotLayer;
import net.offkung.bhweapons.client.renderer.SheathedSwordRenderer;
import yesman.epicfight.api.client.forgeevent.PatchedRenderersEvent;

@Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD, modid = BHWeapons.MODID)
public class BHWeaponsClient {
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        BHWeapons.LOGGER.info("BHWeapons Client Setup Initialized!");
    }

    @SubscribeEvent
    public static void registerPatchedRenderers(PatchedRenderersEvent.RegisterItemRenderer event) {
        event.addItemRenderer(ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "wuchen_jian"), SheathedSwordRenderer::new);
        event.addItemRenderer(ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "taixu_zhenxie"), SheathedSwordRenderer::new);
    }

    @SubscribeEvent
    public static void onAddLayers(EntityRenderersEvent.AddLayers event) {
        for (String skinName : event.getSkins()) {
            PlayerRenderer renderer = event.getSkin(skinName);
            if (renderer != null) {
                renderer.addLayer(new MobaiHanzhiSlotLayer(renderer));
            }
        }
    }
}
