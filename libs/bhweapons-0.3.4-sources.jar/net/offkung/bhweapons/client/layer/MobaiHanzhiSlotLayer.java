package net.offkung.bhweapons.client.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.offkung.bhweapons.item.mobai_hanzhi.MobaiHanzhiItem;

public class MobaiHanzhiSlotLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public static final ThreadLocal<Boolean> RENDERING_SLOT0 = ThreadLocal.withInitial(() -> false);

    public MobaiHanzhiSlotLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> renderer) {
        super(renderer);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        ItemStack slot0Stack = player.getInventory().getItem(0);

        if (slot0Stack.isEmpty() || !(slot0Stack.getItem() instanceof MobaiHanzhiItem)) {
            return;
        }

        if (player.getMainHandItem().getItem() instanceof MobaiHanzhiItem) {
            return;
        }

        poseStack.pushPose();

        this.getParentModel().body.translateAndRotate(poseStack);
        poseStack.mulPose(Axis.XP.rotationDegrees(-90.0F));
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F));
        poseStack.translate(-7.0F / 16.0F, 0.12F, -0.85F);

        try {
            RENDERING_SLOT0.set(true);
            Minecraft.getInstance().getItemRenderer().renderStatic(
                    player,
                    slot0Stack,
                    ItemDisplayContext.THIRD_PERSON_LEFT_HAND,
                    true,
                    poseStack,
                    buffer,
                    player.level(),
                    packedLight,
                    OverlayTexture.NO_OVERLAY,
                    player.getId()
            );
        } finally {
            RENDERING_SLOT0.set(false);
        }

        poseStack.popPose();
    }
}
