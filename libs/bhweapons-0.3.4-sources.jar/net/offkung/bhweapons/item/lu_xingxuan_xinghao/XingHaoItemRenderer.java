package net.offkung.bhweapons.item.lu_xingxuan_xinghao;

import software.bernie.geckolib.renderer.GeoItemRenderer;

public class XingHaoItemRenderer extends GeoItemRenderer<XingHaoItem> {
    public XingHaoItemRenderer() {
        super(new XingHaoItemModel());
    }
}
