package net.offkung.bhweapons.item.lu_xingxuan_xinghao;

import net.minecraft.resources.ResourceLocation;
import net.offkung.bhweapons.BHWeapons;
import software.bernie.geckolib.model.GeoModel;

public class XingHaoItemModel extends GeoModel<XingHaoItem> {
    @Override
    public ResourceLocation getModelResource(XingHaoItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "geo/lu_xingxuan_xinghao.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(XingHaoItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "textures/item/lu_xingxuan/celinemiller.png");
    }

    @Override
    public ResourceLocation getAnimationResource(XingHaoItem animatable) {
        return null;
    }
}
