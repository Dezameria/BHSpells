package net.offkung.bhweapons.item.wuchen_jian;

import software.bernie.geckolib.renderer.GeoItemRenderer;

public class WuchenJianItemRenderer extends GeoItemRenderer<WuchenJianItem> {
    public WuchenJianItemRenderer() {
        super(new WuchenJianItemModel());
    }
}
