package net.offkung.bhweapons.item.wuchen_jian;

import net.minecraft.resources.ResourceLocation;
import net.offkung.bhweapons.BHWeapons;
import software.bernie.geckolib.model.GeoModel;

public class WuchenJianItemModel extends GeoModel<WuchenJianItem> {
    @Override
    public ResourceLocation getModelResource(WuchenJianItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "geo/wuchen_jian_sword.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(WuchenJianItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "textures/item/wuchen_jian/sword_tex.png");
    }

    @Override
    public ResourceLocation getAnimationResource(WuchenJianItem animatable) {
        return null;
    }
}
