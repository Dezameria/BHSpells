package net.offkung.bhweapons.item.wuchen_jian;

import software.bernie.geckolib.renderer.GeoItemRenderer;

public class WuchenJianSheathItemRenderer extends GeoItemRenderer<WuchenJianSheathItem> {
    public WuchenJianSheathItemRenderer() {
        super(new WuchenJianSheathItemModel());
    }
}
