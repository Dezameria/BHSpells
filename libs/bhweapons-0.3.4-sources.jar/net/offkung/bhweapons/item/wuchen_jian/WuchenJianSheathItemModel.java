package net.offkung.bhweapons.item.wuchen_jian;

import net.minecraft.resources.ResourceLocation;
import net.offkung.bhweapons.BHWeapons;
import software.bernie.geckolib.model.GeoModel;

public class WuchenJianSheathItemModel extends GeoModel<WuchenJianSheathItem> {
    @Override
    public ResourceLocation getModelResource(WuchenJianSheathItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "geo/wuchen_jian_sheath.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(WuchenJianSheathItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "textures/item/wuchen_jian/sword_tex.png");
    }

    @Override
    public ResourceLocation getAnimationResource(WuchenJianSheathItem animatable) {
        return null;
    }
}
