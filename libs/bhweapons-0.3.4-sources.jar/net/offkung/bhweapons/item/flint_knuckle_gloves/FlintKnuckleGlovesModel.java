package net.offkung.bhweapons.item.flint_knuckle_gloves;

import net.minecraft.resources.ResourceLocation;
import net.offkung.bhweapons.BHWeapons;
import software.bernie.geckolib.model.GeoModel;

public class FlintKnuckleGlovesModel extends GeoModel<FlintKnuckleGloves> {
    @Override
    public ResourceLocation getModelResource(FlintKnuckleGloves animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "geo/flint_knuckle_gloves.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(FlintKnuckleGloves animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "textures/item/flint_knuckle_gloves/glove.png");
    }

    @Override
    public ResourceLocation getAnimationResource(FlintKnuckleGloves animatable) {
        return null;
    }
}
