package net.offkung.bhweapons.item.flint_knuckle_gloves;

import software.bernie.geckolib.renderer.GeoItemRenderer;

public class FlintKnuckleGlovesRenderer extends GeoItemRenderer<FlintKnuckleGloves> {
    public FlintKnuckleGlovesRenderer() {
        super(new FlintKnuckleGlovesModel());
    }
}
