package net.offkung.bhweapons.item.yang_fan;

import net.minecraft.resources.ResourceLocation;
import net.offkung.bhweapons.BHWeapons;
import software.bernie.geckolib.model.GeoModel;

public class CloseYangFanItemModel extends GeoModel<CloseYangFanItem> {
    @Override
    public ResourceLocation getModelResource(CloseYangFanItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "geo/close_yang_fan.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(CloseYangFanItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "textures/item/yang_fan/close_yang.png");
    }

    @Override
    public ResourceLocation getAnimationResource(CloseYangFanItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "animations/close_yang_fan.animation.json");
    }
}
