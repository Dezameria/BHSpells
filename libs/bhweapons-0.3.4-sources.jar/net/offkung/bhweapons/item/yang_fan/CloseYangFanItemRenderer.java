package net.offkung.bhweapons.item.yang_fan;

import software.bernie.geckolib.renderer.GeoItemRenderer;

public class CloseYangFanItemRenderer extends GeoItemRenderer<CloseYangFanItem> {
    public CloseYangFanItemRenderer() {
        super(new CloseYangFanItemModel());
    }
}
