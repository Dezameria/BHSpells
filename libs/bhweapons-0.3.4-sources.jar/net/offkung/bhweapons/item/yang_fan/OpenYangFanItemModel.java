package net.offkung.bhweapons.item.yang_fan;

import net.minecraft.resources.ResourceLocation;
import net.offkung.bhweapons.BHWeapons;
import software.bernie.geckolib.model.GeoModel;

public class OpenYangFanItemModel extends GeoModel<OpenYangFanItem> {
    @Override
    public ResourceLocation getModelResource(OpenYangFanItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "geo/open_yang_fan.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(OpenYangFanItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "textures/item/yang_fan/close_yang.png");
    }

    @Override
    public ResourceLocation getAnimationResource(OpenYangFanItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "animations/open_yang_fan.animation.json");
    }
}
