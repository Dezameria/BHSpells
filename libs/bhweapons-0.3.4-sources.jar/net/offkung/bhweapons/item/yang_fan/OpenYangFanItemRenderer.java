package net.offkung.bhweapons.item.yang_fan;

import software.bernie.geckolib.renderer.GeoItemRenderer;

public class OpenYangFanItemRenderer extends GeoItemRenderer<OpenYangFanItem> {
    public OpenYangFanItemRenderer() {
        super(new OpenYangFanItemModel());
    }
}
