package net.offkung.bhweapons.item.taixu_zhenxie;

import net.minecraft.resources.ResourceLocation;
import net.offkung.bhweapons.BHWeapons;
import software.bernie.geckolib.model.GeoModel;

public class TaixuZhenxieSheathItemModel extends GeoModel<TaixuZhenxieSheathItem> {
    @Override
    public ResourceLocation getModelResource(TaixuZhenxieSheathItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "geo/taixu_zhenxie_sheath.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(TaixuZhenxieSheathItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "textures/item/taixu_zhenxie/taixu_zhenxie.png");
    }

    @Override
    public ResourceLocation getAnimationResource(TaixuZhenxieSheathItem animatable) {
        return null;
    }
}
