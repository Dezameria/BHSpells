package net.offkung.bhweapons.item.taixu_zhenxie;

import software.bernie.geckolib.renderer.GeoItemRenderer;

public class TaixuZhenxieRenderer extends GeoItemRenderer<TaixuZhenxieItem> {
    public TaixuZhenxieRenderer() {
        super(new TaixuZhenxieModel());
    }
}
