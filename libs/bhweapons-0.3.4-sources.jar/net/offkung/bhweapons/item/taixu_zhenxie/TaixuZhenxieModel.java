package net.offkung.bhweapons.item.taixu_zhenxie;

import net.minecraft.resources.ResourceLocation;
import net.offkung.bhweapons.BHWeapons;
import net.offkung.bhweapons.item.wuchen_jian.WuchenJianItem;
import software.bernie.geckolib.model.GeoModel;

public class TaixuZhenxieModel extends GeoModel<TaixuZhenxieItem> {
    @Override
    public ResourceLocation getModelResource(TaixuZhenxieItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "geo/taixu_zhenxie.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(TaixuZhenxieItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "textures/item/taixu_zhenxie/taixu_zhenxie.png");
    }

    @Override
    public ResourceLocation getAnimationResource(TaixuZhenxieItem animatable) {
        return null;
    }
}
