package net.offkung.bhweapons.item.taixu_zhenxie;

import software.bernie.geckolib.renderer.GeoItemRenderer;

public class TaixuZhenxieSheathItemRenderer extends GeoItemRenderer<TaixuZhenxieSheathItem> {
    public TaixuZhenxieSheathItemRenderer() {
        super(new TaixuZhenxieSheathItemModel());
    }
}
