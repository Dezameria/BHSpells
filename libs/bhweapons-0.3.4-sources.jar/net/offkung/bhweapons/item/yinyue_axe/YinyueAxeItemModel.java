package net.offkung.bhweapons.item.yinyue_axe;

import net.minecraft.resources.ResourceLocation;
import net.offkung.bhweapons.BHWeapons;
import software.bernie.geckolib.model.GeoModel;

public class YinyueAxeItemModel extends GeoModel<YinyueAxeItem> {
    @Override
    public ResourceLocation getModelResource(YinyueAxeItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "geo/yinyue_axe.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(YinyueAxeItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "textures/item/yinyue_axe/yinyue_axe.png");
    }

    @Override
    public ResourceLocation getAnimationResource(YinyueAxeItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "animations/yinyue_axe.animation.json");
    }
}
