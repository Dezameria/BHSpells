package net.offkung.bhweapons.item.yinyue_axe;

import software.bernie.geckolib.renderer.GeoItemRenderer;

public class YinyueAxeItemRenderer extends GeoItemRenderer<YinyueAxeItem> {
    public YinyueAxeItemRenderer() {
        super(new YinyueAxeItemModel());
    }
}
