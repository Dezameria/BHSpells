package net.offkung.bhweapons.item.beeboych_marble;

import software.bernie.geckolib.renderer.GeoItemRenderer;

public class BeeBoyCHMarbleItemRenderer extends GeoItemRenderer<BeeBoyCHMarbleItem> {
    public BeeBoyCHMarbleItemRenderer() {
        super(new BeeBoyCHMarbleItemModel());
    }
}
