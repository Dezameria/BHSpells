package net.offkung.bhweapons.item.beeboych_marble;

import net.minecraft.resources.ResourceLocation;
import net.offkung.bhweapons.BHWeapons;
import software.bernie.geckolib.model.GeoModel;

public class BeeBoyCHMarbleItemModel extends GeoModel<BeeBoyCHMarbleItem> {
    @Override
    public ResourceLocation getModelResource(BeeBoyCHMarbleItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "geo/beeboych_marble.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(BeeBoyCHMarbleItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "textures/item/beeboych_marble/marble_texture.png");
    }

    @Override
    public ResourceLocation getAnimationResource(BeeBoyCHMarbleItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "animations/beeboych_marble.animation.json");
    }
}
