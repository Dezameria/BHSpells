package net.offkung.bhweapons.item.yaoyao_pokpak;

import software.bernie.geckolib.renderer.GeoItemRenderer;

public class YaoYaoSwordItemRenderer extends GeoItemRenderer<YaoYaoSwordItem> {
    public YaoYaoSwordItemRenderer() {
        super(new YaoYaoSwordModel());
    }
}
