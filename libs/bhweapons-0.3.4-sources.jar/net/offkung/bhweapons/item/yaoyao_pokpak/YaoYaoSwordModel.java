package net.offkung.bhweapons.item.yaoyao_pokpak;

import net.minecraft.resources.ResourceLocation;
import net.offkung.bhweapons.BHWeapons;
import software.bernie.geckolib.model.GeoModel;

public class YaoYaoSwordModel extends GeoModel<YaoYaoSwordItem> {
    @Override
    public ResourceLocation getModelResource(YaoYaoSwordItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "geo/yaoyao_pokpak.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(YaoYaoSwordItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "textures/item/yaoyao_pokpak/ag.png");
    }

    @Override
    public ResourceLocation getAnimationResource(YaoYaoSwordItem animatable) {
        return null;
    }
}
