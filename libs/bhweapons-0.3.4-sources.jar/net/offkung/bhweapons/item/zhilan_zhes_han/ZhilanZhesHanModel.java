package net.offkung.bhweapons.item.zhilan_zhes_han;

import net.minecraft.resources.ResourceLocation;
import net.offkung.bhweapons.BHWeapons;
import software.bernie.geckolib.model.GeoModel;

public class ZhilanZhesHanModel extends GeoModel<ZhilanZhesHan> {
    @Override
    public ResourceLocation getModelResource(ZhilanZhesHan animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "geo/zhilan_zhes_han.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(ZhilanZhesHan animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "textures/item/zhilan_zhes_han/g.png");
    }

    @Override
    public ResourceLocation getAnimationResource(ZhilanZhesHan animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "animations/zhilan_zhes_han.animation.json");
    }
}
