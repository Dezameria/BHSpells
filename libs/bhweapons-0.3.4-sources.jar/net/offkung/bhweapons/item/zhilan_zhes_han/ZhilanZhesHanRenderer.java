package net.offkung.bhweapons.item.zhilan_zhes_han;

import software.bernie.geckolib.renderer.GeoItemRenderer;

public class ZhilanZhesHanRenderer extends GeoItemRenderer<ZhilanZhesHan> {
    public ZhilanZhesHanRenderer() {
        super(new ZhilanZhesHanModel());
    }
}
