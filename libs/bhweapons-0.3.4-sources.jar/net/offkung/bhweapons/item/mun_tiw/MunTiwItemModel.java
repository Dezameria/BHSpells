package net.offkung.bhweapons.item.mun_tiw;

import net.minecraft.resources.ResourceLocation;
import net.offkung.bhweapons.BHWeapons;
import software.bernie.geckolib.model.GeoModel;

public class MunTiwItemModel extends GeoModel<MunTiwItem> {
    @Override
    public ResourceLocation getModelResource(MunTiwItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "geo/mun_tiw.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(MunTiwItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "textures/item/mun_tiw/mun_tiw_texture.png");
    }

    @Override
    public ResourceLocation getAnimationResource(MunTiwItem animatable) {
        return null;
    }
}
