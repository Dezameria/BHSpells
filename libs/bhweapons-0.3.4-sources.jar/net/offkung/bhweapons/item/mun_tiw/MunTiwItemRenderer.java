package net.offkung.bhweapons.item.mun_tiw;

import software.bernie.geckolib.renderer.GeoItemRenderer;

public class MunTiwItemRenderer extends GeoItemRenderer<MunTiwItem> {
    public MunTiwItemRenderer() {
        super(new MunTiwItemModel());
    }
}
