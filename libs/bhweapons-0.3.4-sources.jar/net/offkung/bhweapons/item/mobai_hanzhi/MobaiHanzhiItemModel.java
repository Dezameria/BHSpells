package net.offkung.bhweapons.item.mobai_hanzhi;

import net.minecraft.resources.ResourceLocation;
import net.offkung.bhweapons.BHWeapons;
import software.bernie.geckolib.model.GeoModel;

public class MobaiHanzhiItemModel extends GeoModel<MobaiHanzhiItem> {
    @Override
    public ResourceLocation getModelResource(MobaiHanzhiItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "geo/mobai_hanzhi.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(MobaiHanzhiItem animatable) {
        return ResourceLocation.fromNamespaceAndPath(BHWeapons.MODID, "textures/item/mobai_hanzhi/a1.png");
    }

    @Override
    public ResourceLocation getAnimationResource(MobaiHanzhiItem animatable) {
        return null;
    }
}
