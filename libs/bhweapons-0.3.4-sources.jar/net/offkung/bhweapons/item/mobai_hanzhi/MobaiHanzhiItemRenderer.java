package net.offkung.bhweapons.item.mobai_hanzhi;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.offkung.bhweapons.client.layer.MobaiHanzhiSlotLayer;
import software.bernie.geckolib.renderer.GeoItemRenderer;

public class MobaiHanzhiItemRenderer extends GeoItemRenderer<MobaiHanzhiItem> {
    public MobaiHanzhiItemRenderer() {
        super(new MobaiHanzhiItemModel());
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext transformType, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
        if (transformType == ItemDisplayContext.THIRD_PERSON_LEFT_HAND && !MobaiHanzhiSlotLayer.RENDERING_SLOT0.get()) {
            return;
        }

        super.renderByItem(stack, transformType, poseStack, bufferSource, packedLight, packedOverlay);
    }
}
