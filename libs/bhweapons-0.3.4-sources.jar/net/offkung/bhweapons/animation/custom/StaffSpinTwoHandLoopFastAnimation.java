package net.offkung.bhweapons.animation.custom;

import com.p1nero.wukong.client.event.CameraAnim;
import net.minecraft.client.player.LocalPlayer;
import yesman.epicfight.api.animation.AnimationManager.AnimationAccessor;
import yesman.epicfight.api.animation.property.AnimationEvent.Side;
import yesman.epicfight.api.animation.property.AnimationEvent.SimpleEvent;
import yesman.epicfight.api.animation.property.AnimationProperty.ActionAnimationProperty;
import yesman.epicfight.api.animation.property.AnimationProperty.StaticAnimationProperty;
import yesman.epicfight.api.animation.property.MoveCoordFunctions;
import yesman.epicfight.api.animation.types.AttackAnimation;
import yesman.epicfight.api.animation.types.AttackAnimation.Phase;
import yesman.epicfight.api.animation.types.DynamicAnimation;
import yesman.epicfight.api.animation.types.EntityState;
import yesman.epicfight.api.asset.AssetAccessor;
import yesman.epicfight.api.utils.math.Vec3f;
import yesman.epicfight.gameasset.Armatures;
import yesman.epicfight.model.armature.HumanoidArmature;
import yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch;

public class StaffSpinTwoHandLoopFastAnimation extends AttackAnimation {
    private static final float FAST_PLAY_SPEED = 1.8F;
    private static final float END = 0.83F;
    private static final float MOVE_DISTANCE_PER_LOOP = 1.3F;

    public StaffSpinTwoHandLoopFastAnimation(AnimationAccessor<? extends AttackAnimation> accessor) {
        super(0.0F, accessor, Armatures.BIPED, buildPhases());

        this.setResourceLocation("wukong", "biped/staff_spin/staff_spin_two_hand");

        this.addProperty(ActionAnimationProperty.CANCELABLE_MOVE, false);
        this.addProperty(StaticAnimationProperty.PLAY_SPEED_MODIFIER,
                (dynamicAnimation, entitypatch, speed, prevElapsedTime, elapsedTime) -> FAST_PLAY_SPEED);
        this.addEvents(StaticAnimationProperty.ON_BEGIN_EVENTS, SimpleEvent.create((entitypatch, animation, params) -> {
            if (entitypatch.getOriginal() instanceof LocalPlayer) {
                CameraAnim.zoomIn(new Vec3f(-1.0F, 0.0F, 1.25F), 20);
            }
        }, Side.CLIENT));

        // Steer movement toward wherever the player is looking instead of the default target-chasing coord.
        this.addProperty(ActionAnimationProperty.COORD_SET_BEGIN, (animation, entitypatch, transformSheet) -> {
            if (!animation.isLinkAnimation()) {
                transformSheet.readFrom(animation.getCoord().copyAll().extendsZCoord(MOVE_DISTANCE_PER_LOOP, 0, 2));
            } else {
                MoveCoordFunctions.RAW_COORD.set(animation, entitypatch, transformSheet);
            }
        });
        this.addProperty(ActionAnimationProperty.COORD_SET_TICK, null);
        this.addProperty(ActionAnimationProperty.MOVE_VERTICAL, false);
        this.addProperty(ActionAnimationProperty.ENTITY_YROT_PROVIDER, (self, entitypatch) -> entitypatch.getOriginal().yHeadRot);
    }

    private static Phase[] buildPhases() {
        HumanoidArmature biped = Armatures.BIPED.get();

        return new Phase[]{
                new Phase(0.0F, 0.0F, 0.25F, END, 0.26F, biped.toolR, null),
                new Phase(0.24F, 0.25F, 0.5F, END, 0.51F, biped.toolR, null),
                new Phase(0.49F, 0.5F, 0.75F, END, 0.76F, biped.toolR, null),
                new Phase(0.74F, 0.74F, 1.0F, END, END, biped.toolR, null)
        };
    }

    @Override
    protected void hurtCollidingEntities(LivingEntityPatch<?> entitypatch, float prevElapsedTime, float elapsedTime, EntityState prevState, EntityState state, Phase phase) {
    }

    @Override
    public void end(LivingEntityPatch<?> entitypatch, AssetAccessor<? extends DynamicAnimation> nextAnimation, boolean isEnd) {
        super.end(entitypatch, nextAnimation, isEnd);
        if (entitypatch.isLogicalClient() && CameraAnim.isAiming()) {
            CameraAnim.zoomOut(20);
        }
        if (isEnd && !entitypatch.isLogicalClient()) {
            entitypatch.playAnimationSynchronized(this.getAccessor(), 0.0F);
        }
    }
}
